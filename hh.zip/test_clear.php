<?php
  setcookie("new-user", "", time()+60*30, "/");
?>