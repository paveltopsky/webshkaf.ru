<!-- Выйти из аккаунта -->
<form action="functions/exit.php" method="POST" enctype="application/x-www-form-urlencoded">
  <button type="submit" class="btn btn-primary" style="width: 200px; margin-top: 20px;">Выйти</button>
</form>