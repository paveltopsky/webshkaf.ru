<!-- Bootstrap core JavaScript-->
<script src="vendor/jquery/jquery-3.4.1.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.min.js"></script>

<!-- Custom scripts for all pages-->
<script src="../js/main.js"></script>